/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stqa_practical_7;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author patol
 */
public class Stqa_practical_7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\patol\\Downloads\\chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.get("https://google.com");
        driver.manage().window().maximize();
        List <WebElement>links = driver.findElements(By.tagName("a"));
         List <WebElement>buttons = driver.findElements(By.tagName("button"));
          List <WebElement>fields = driver.findElements(By.tagName("input"));
          System.out.println("Total No.of Links = " + links.size());
          System.out.println("Total No.of Button = " + buttons.size());
          System.out.println("Total No.of fields = " + fields.size());
     }
    }
