/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mypack;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

/**
 *
 * @author cs2
 */
@WebService(serviceName = "channel")
public class channel {


    /**
     * Web service operation
     */
    @WebMethod(operationName = "getBreakingNews")
    public String getBreakingNews(@WebParam(name = "date") String date) {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/channel","user1","123");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM BREAKINGNEWS WHERE DATES = '"+date+"'");
            if(rs.next()){
                return date+":"+rs.getString("NEWS");
            }
            else{
                return "News will be updated";
            }
        }
        catch(Exception e)
        {
            return e.toString();
        }
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "getSunSign")
    public String getSunSign(@WebParam(name = "sign") String sign) {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/channel","user1","123");
            Statement stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SUNSIGN WHERE SIGN = '"+sign+"'");
            if(rs.next()){
                return sign+":"+rs.getString("PREDICTION");
            }
            else{
                return "Sorry no Zodiac sign exist.";
            }
        }
        catch(Exception e)
        {
            return e.toString();
        }
    }
}
