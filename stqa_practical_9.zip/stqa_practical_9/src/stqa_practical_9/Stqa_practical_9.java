/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stqa_practical_9;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 *
 * @author patol
 */
public class Stqa_practical_9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       System.setProperty("webdriver.chrome.driver","C:\\Users\\patol\\Downloads\\chromedriver.exe");
        WebDriver driver= new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost/checkbox.html");
        List<WebElement> checkbox= driver.findElements(By.xpath("//input[@type='checkbox']"));
        int checked=0 , unchecked=0;
        for(int i=0;i<checkbox.size();i++){
            if(checkbox.get(i).isSelected()){
                checked++;
            }
            else{
                unchecked++;
                }

        }
        System.out.println("total no.of checkbox is checked:" + checked);
        System.out.println("total no.of checkbox is unchecked:" + unchecked);
        driver.quit();

      
    }
 
    }
    

