/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package stqa_practical_4;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 *
 * @author patol
 */
public class Stqa_practical_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver","C:\\Users\\patol\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost/login.html");
        driver.findElement(By.id("user")).sendKeys("sanika");
        driver.findElement(By.id("pass")).sendKeys("sanika123");
        driver.findElement(By.id("btn")).click();
        if(driver.getTitle().contains("Welcome"))
        {
            System.out.println("Login Successful!");
        }
        else
        {
            System.out.println("Login Failed!");
        }
        driver.quit();
    }
}



    
    

